package com.example.foodhub.model

class FoodItem(
    val id: String,
    val name: String,
    val cost_for_one: Int) {
}