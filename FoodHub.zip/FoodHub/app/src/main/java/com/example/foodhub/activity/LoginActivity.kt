package com.example.foodhub.activity

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.foodhub.R
import com.example.foodhub.util.ConnectionManager
import org.json.JSONException
import org.json.JSONObject

class LoginActivity: AppCompatActivity() {
    private lateinit var etMobileNumber: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogIn: Button
    private lateinit var txtForgotPassword: TextView
    private lateinit var txtRegister: TextView
    lateinit var progressBar: ProgressBar

    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedPreferences =
            getSharedPreferences(getString(R.string.preferences_file_name), Context.MODE_PRIVATE)
        setContentView(R.layout.activity_login)
        val isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false)

        if(isLoggedIn) {
            val intent = Intent(this@LoginActivity, MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        etMobileNumber = findViewById(R.id.etMobileNumber)
        etPassword = findViewById(R.id.etpassword)
        btnLogIn = findViewById(R.id.btnLogIn)
        txtForgotPassword = findViewById(R.id.txtForgotPassword)
        txtRegister = findViewById(R.id.txtRegister)
        progressBar = findViewById(R.id.progressBarLogin)
        progressBar.visibility = View.GONE

        btnLogIn.setOnClickListener {
            val mobileNumber = etMobileNumber.text.toString()
            val password = etPassword.text.toString()
            val intent = Intent(this, MainActivity::class.java)

            val queue = Volley.newRequestQueue(this)
            val url = "http://13.235.250.119/v2/login/fetch_result/"

            if(ConnectionManager().checkConnectivity(this)) {
                progressBar.visibility = View.VISIBLE
                val jsonParams = JSONObject()
                jsonParams.put("mobile_number", mobileNumber)
                jsonParams.put("password", password)

                val jsonObjectRequest =
                    object: JsonObjectRequest(Method.POST, url, jsonParams, Response.Listener {
                        try {
                            progressBar.visibility = View.GONE
                            val data = it.getJSONObject("data")
                            Log.i("json", "The data is $data")
                            val success = data.getBoolean("success")
                            if(success) {
                                val response = data.getJSONObject("data")
                                Log.i("response", "The response is $response")

                                sharedPreferences.edit().putString("user_id", response.getString("user_id"))
                                    .apply()
                                sharedPreferences.edit().putString("user_mobile_number", response.getString("mobile_number"))
                                    .apply()
                                sharedPreferences.edit().putString("user_name", response.getString("name"))
                                    .apply()
                                sharedPreferences.edit().putString("user_email", response.getString("email"))
                                    .apply()
                                sharedPreferences.edit().putString("user_address", response.getString("address"))
                                    .apply()
                                sharedPreferences.edit().putBoolean("isLoggedIn", true).apply()
                                    startActivity(intent)
                            }
                            else {
                                Toast.makeText(this, "Incorrect Credentials", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: JSONException) {
                            Log.i("jsonError", "The error is $it")
                        }
                }, Response.ErrorListener {
                        Toast.makeText(
                            this,
                            "A Volley error occurred!",
                            Toast.LENGTH_LONG
                        ).show()
                    }) {
                    override fun getHeaders(): MutableMap<String, String> {
                        val headers = HashMap<String, String>()
                        headers["Content-type"] = "application/json"
                        headers["token"] = "deb6a2b542c8d1"
                        return headers
                    }
                }
                queue.add(jsonObjectRequest)
            }
            else {
                val dialog = AlertDialog.Builder(this)
                dialog.setTitle("Error ")
                dialog.setMessage("Internet Connection Not Found")
                dialog.setPositiveButton("Open Settings") { text, listener ->
                    val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                    startActivity(settingsIntent)
                    finish()
                }
                dialog.setNegativeButton("Exit") { text, listener ->
                    ActivityCompat.finishAffinity(this)
                }
                dialog.create()
                dialog.show()
            }
        }

        txtRegister.setOnClickListener {
            val intent = Intent(this@LoginActivity, RegistrationActivity::class.java)
            startActivity(intent)
            finish()
        }

        txtForgotPassword.setOnClickListener {
            val intent = Intent(this@LoginActivity, ForgotPasswordActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    override fun onPause() {
        super.onPause()
        finish()
    }
}